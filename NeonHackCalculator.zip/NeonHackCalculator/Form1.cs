using System.Globalization;

namespace NeonHackCalculator;

public partial class Form1 : Form
{
    private string _currentInput = "0";
    private double? _storedValue;
    private string? _pendingOperator;
    private bool _startNewNumber = true;
    private bool _hasError;

    public Form1()
    {
        InitializeComponent();
        UpdateDisplay();
        AddLog("SYSTEM READY // SECURE CALCULATION CORE ONLINE");
    }

    private void NumberButton_Click(object? sender, EventArgs e)
    {
        if (sender is not Button button) return;
        if (_hasError) ClearAll();

        string digit = button.Tag?.ToString() ?? button.Text;
        if (_startNewNumber)
        {
            _currentInput = digit == "." ? "0." : digit;
            _startNewNumber = false;
        }
        else if (digit == ".")
        {
            if (!_currentInput.Contains('.')) _currentInput += ".";
        }
        else
        {
            _currentInput = _currentInput == "0" ? digit : _currentInput + digit;
        }

        UpdateDisplay();
    }

    private void OperatorButton_Click(object? sender, EventArgs e)
    {
        if (sender is not Button button) return;
        if (!double.TryParse(_currentInput, NumberStyles.Float, CultureInfo.InvariantCulture, out double value)) return;

        if (_storedValue.HasValue && _pendingOperator is not null && !_startNewNumber)
            Calculate();

        _storedValue = double.Parse(_currentInput, CultureInfo.InvariantCulture);
        _pendingOperator = button.Tag?.ToString() ?? button.Text;
        _startNewNumber = true;
        AddLog($"OPERATOR LOCKED // {_pendingOperator}");
        UpdateDisplay();
    }

    private void EqualsButton_Click(object? sender, EventArgs e)
    {
        if (_pendingOperator is null || !_storedValue.HasValue) return;
        Calculate();
    }

    private void Calculate()
    {
        double left = _storedValue!.Value;
        double right = double.Parse(_currentInput, CultureInfo.InvariantCulture);
        double result;

        try
        {
            result = _pendingOperator switch
            {
                "+" => left + right,
                "−" or "-" => left - right,
                "×" or "*" => left * right,
                "÷" or "/" when right != 0 => left / right,
                "÷" or "/" => throw new DivideByZeroException(),
                "%" => left % right,
                _ => right
            };

            if (double.IsNaN(result) || double.IsInfinity(result))
                throw new ArithmeticException();

            AddLog($"{Format(left)} {_pendingOperator} {Format(right)} = {Format(result)}");
            _currentInput = result.ToString("G15", CultureInfo.InvariantCulture);
            _storedValue = null;
            _pendingOperator = null;
            _startNewNumber = true;
            _hasError = false;
        }
        catch (DivideByZeroException)
        {
            ShowError("DIVISION BY ZERO");
        }
        catch
        {
            ShowError("INVALID OPERATION");
        }

        UpdateDisplay();
    }

    private void ClearButton_Click(object? sender, EventArgs e) => ClearAll();

    private void ClearAll()
    {
        _currentInput = "0";
        _storedValue = null;
        _pendingOperator = null;
        _startNewNumber = true;
        _hasError = false;
        AddLog("BUFFER CLEARED // READY");
        UpdateDisplay();
    }

    private void BackspaceButton_Click(object? sender, EventArgs e)
    {
        if (_hasError) { ClearAll(); return; }
        if (_startNewNumber) return;
        _currentInput = _currentInput.Length <= 1 || (_currentInput.Length == 2 && _currentInput[0] == '-')
            ? "0" : _currentInput[..^1];
        UpdateDisplay();
    }

    private void SignButton_Click(object? sender, EventArgs e)
    {
        if (_hasError) return;
        if (_currentInput != "0")
            _currentInput = _currentInput.StartsWith('-') ? _currentInput[1..] : "-" + _currentInput;
        UpdateDisplay();
    }

    private void PercentButton_Click(object? sender, EventArgs e)
    {
        if (_hasError) return;
        double value = double.Parse(_currentInput, CultureInfo.InvariantCulture);
        _currentInput = (value / 100d).ToString("G15", CultureInfo.InvariantCulture);
        UpdateDisplay();
    }

    private void ShowError(string message)
    {
        _currentInput = "ERROR";
        _storedValue = null;
        _pendingOperator = null;
        _startNewNumber = true;
        _hasError = true;
        AddLog($"ERROR // {message}");
    }

    private void UpdateDisplay()
    {
        DisplayLabel.Text = _currentInput;
        ExpressionLabel.Text = _storedValue.HasValue && _pendingOperator is not null
            ? $"{Format(_storedValue.Value)}  {_pendingOperator}" : "READY FOR INPUT";
    }

    private static string Format(double value) => value.ToString("G12", CultureInfo.InvariantCulture);

    private void AddLog(string message)
    {
        LogList.Items.Insert(0, $"[{DateTime.Now:HH:mm:ss}]  {message}");
        while (LogList.Items.Count > 7) LogList.Items.RemoveAt(LogList.Items.Count - 1);
    }

    private void CopyButton_Click(object? sender, EventArgs e)
    {
        if (!_hasError) Clipboard.SetText(_currentInput);
        AddLog("OUTPUT COPIED TO CLIPBOARD");
    }

    private void Form1_KeyDown(object? sender, KeyEventArgs e)
    {
        if (e.KeyCode >= Keys.D0 && e.KeyCode <= Keys.D9 && !e.Shift)
            ClickByText((e.KeyCode - Keys.D0).ToString());
        else if (e.KeyCode >= Keys.NumPad0 && e.KeyCode <= Keys.NumPad9)
            ClickByText((e.KeyCode - Keys.NumPad0).ToString());
        else if (e.KeyCode == Keys.Enter) EqualsButton.PerformClick();
        else if (e.KeyCode == Keys.Back) BackspaceButton.PerformClick();
        else if (e.KeyCode == Keys.Escape) ClearAll();
        else if (e.KeyCode == Keys.Add) ClickByTag("+");
        else if (e.KeyCode == Keys.Subtract) ClickByTag("−");
        else if (e.KeyCode == Keys.Multiply) ClickByTag("×");
        else if (e.KeyCode == Keys.Divide) ClickByTag("÷");
        else if (e.KeyCode == Keys.Decimal || e.KeyCode == Keys.OemPeriod) ClickByText(".");
    }

    private void ClickByText(string text)
    {
        foreach (Control control in KeypadPanel.Controls)
            if (control is Button b && b.Text == text) { b.PerformClick(); return; }
    }

    private void ClickByTag(string tag)
    {
        foreach (Control control in KeypadPanel.Controls)
            if (control is Button b && (b.Tag?.ToString() == tag)) { b.PerformClick(); return; }
    }
}
