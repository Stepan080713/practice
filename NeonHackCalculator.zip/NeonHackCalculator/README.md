# NEXUS Calculator

Windows Forms calculator for Visual Studio (.NET 8).

## Open
1. Extract `NeonHackCalculator.zip`.
2. Open `NeonHackCalculator.csproj` in Visual Studio 2022.
3. Ensure the **.NET desktop development** workload is installed.
4. Press F5.

Includes the form designer (`Form1.Designer.cs`), calculator logic (`Form1.cs`), and startup file (`Program.cs`).

Features: arithmetic, percent, sign toggle, backspace, clear, keyboard input, copy result, and local activity log.
