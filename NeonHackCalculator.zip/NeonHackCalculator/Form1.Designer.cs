namespace NeonHackCalculator;

partial class Form1
{
    private System.ComponentModel.IContainer? components = null;
    private Label DisplayLabel = null!;
    private Label ExpressionLabel = null!;
    private Panel KeypadPanel = null!;
    private ListBox LogList = null!;
    private Button EqualsButton = null!;
    private Button BackspaceButton = null!;

    protected override void Dispose(bool disposing)
    {
        if (disposing && (components != null)) components.Dispose();
        base.Dispose(disposing);
    }

    private void InitializeComponent()
    {
        components = new System.ComponentModel.Container();
        Text = "NEXUS // CALCULATOR";
        Name = "Form1";
        StartPosition = FormStartPosition.CenterScreen;
        ClientSize = new Size(900, 650);
        MinimumSize = new Size(820, 620);
        BackColor = Color.FromArgb(7, 12, 15);
        ForeColor = Color.FromArgb(220, 245, 232);
        Font = new Font("Segoe UI", 10F);
        KeyPreview = true;
        KeyDown += Form1_KeyDown;

        var header = new Panel { Dock = DockStyle.Top, Height = 76, BackColor = Color.FromArgb(10, 20, 23), Padding = new Padding(28, 13, 24, 10) };
        var brand = new Label { Text = "NEXUS", AutoSize = true, Font = new Font("Consolas", 22F, FontStyle.Bold), ForeColor = Color.FromArgb(0, 255, 145), Location = new Point(24, 12) };
        var subtitle = new Label { Text = "SECURE ARITHMETIC INTERFACE  //  BUILD 01.26", AutoSize = true, Font = new Font("Consolas", 8.5F), ForeColor = Color.FromArgb(100, 145, 129), Location = new Point(145, 28) };
        var status = new Label { Text = "● SYSTEM ONLINE", AutoSize = true, Font = new Font("Consolas", 9F, FontStyle.Bold), ForeColor = Color.FromArgb(0, 255, 145), Anchor = AnchorStyles.Top | AnchorStyles.Right, Location = new Point(735, 27) };
        header.Controls.AddRange(new Control[] { brand, subtitle, status });
        Controls.Add(header);

        var main = new Panel { Dock = DockStyle.Fill, Padding = new Padding(24), BackColor = Color.FromArgb(7, 12, 15) };
        Controls.Add(main);

        var left = new Panel { Dock = DockStyle.Fill, Padding = new Padding(0, 0, 20, 0) };
        var right = new Panel { Dock = DockStyle.Right, Width = 255, BackColor = Color.FromArgb(10, 19, 22), Padding = new Padding(16) };
        main.Controls.Add(left);
        main.Controls.Add(right);

        var displayPanel = new Panel { Dock = DockStyle.Top, Height = 145, BackColor = Color.FromArgb(10, 22, 23), Padding = new Padding(22), BorderStyle = BorderStyle.FixedSingle };
        ExpressionLabel = new Label { Dock = DockStyle.Top, Height = 30, Text = "READY FOR INPUT", TextAlign = ContentAlignment.MiddleRight, Font = new Font("Consolas", 10F), ForeColor = Color.FromArgb(93, 157, 132) };
        DisplayLabel = new Label { Dock = DockStyle.Fill, Text = "0", TextAlign = ContentAlignment.MiddleRight, AutoEllipsis = true, Font = new Font("Consolas", 38F, FontStyle.Bold), ForeColor = Color.FromArgb(0, 255, 145) };
        displayPanel.Controls.Add(DisplayLabel);
        displayPanel.Controls.Add(ExpressionLabel);
        left.Controls.Add(displayPanel);

        KeypadPanel = new Panel { Dock = DockStyle.Fill, Padding = new Padding(0, 18, 0, 0) };
        left.Controls.Add(KeypadPanel);

        var grid = new TableLayoutPanel { Dock = DockStyle.Fill, ColumnCount = 4, RowCount = 5, BackColor = Color.Transparent };
        for (int i = 0; i < 4; i++) grid.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 25F));
        for (int i = 0; i < 5; i++) grid.RowStyles.Add(new RowStyle(SizeType.Percent, 20F));
        KeypadPanel.Controls.Add(grid);

        string[,] keys = {
            { "AC", "⌫", "%", "÷" },
            { "7", "8", "9", "×" },
            { "4", "5", "6", "−" },
            { "1", "2", "3", "+" },
            { "±", "0", ".", "=" }
        };

        for (int row = 0; row < 5; row++)
        for (int col = 0; col < 4; col++)
        {
            string key = keys[row, col];
            var button = new Button
            {
                Text = key, Dock = DockStyle.Fill, Margin = new Padding(5),
                FlatStyle = FlatStyle.Flat, Font = new Font("Consolas", key.Length > 1 ? 13F : 18F, FontStyle.Bold),
                BackColor = IsOperator(key) ? Color.FromArgb(13, 43, 35) : Color.FromArgb(15, 25, 28),
                ForeColor = key == "=" || IsOperator(key) ? Color.FromArgb(0, 255, 145) : Color.FromArgb(213, 232, 223),
                Cursor = Cursors.Hand, Tag = key
            };
            button.FlatAppearance.BorderColor = Color.FromArgb(29, 75, 58);
            button.FlatAppearance.BorderSize = 1;
            button.FlatAppearance.MouseOverBackColor = Color.FromArgb(24, 55, 43);
            button.FlatAppearance.MouseDownBackColor = Color.FromArgb(0, 95, 59);
            button.Click += key switch
            {
                "AC" => ClearButton_Click,
                "⌫" => BackspaceButton_Click,
                "%" => PercentButton_Click,
                "±" => SignButton_Click,
                "=" => EqualsButton_Click,
                "+" or "−" or "×" or "÷" => OperatorButton_Click,
                _ => NumberButton_Click
            };
            if (key is "+" or "−" or "×" or "÷") button.Tag = key;
            if (key == "=") EqualsButton = button;
            if (key == "⌫") BackspaceButton = button;
            grid.Controls.Add(button, col, row);
        }

        var logTitle = new Label { Text = "ACTIVITY LOG", Dock = DockStyle.Top, Height = 35, Font = new Font("Consolas", 11F, FontStyle.Bold), ForeColor = Color.FromArgb(0, 255, 145) };
        var logSub = new Label { Text = "LOCAL SESSION // LAST EVENTS", Dock = DockStyle.Top, Height = 25, Font = new Font("Consolas", 8F), ForeColor = Color.FromArgb(88, 132, 116) };
        LogList = new ListBox { Dock = DockStyle.Fill, BackColor = Color.FromArgb(8, 15, 17), ForeColor = Color.FromArgb(133, 190, 160), BorderStyle = BorderStyle.None, Font = new Font("Consolas", 8.2F), IntegralHeight = false };
        var copy = new Button { Text = "COPY RESULT", Dock = DockStyle.Bottom, Height = 42, FlatStyle = FlatStyle.Flat, BackColor = Color.FromArgb(13, 43, 35), ForeColor = Color.FromArgb(0, 255, 145), Font = new Font("Consolas", 9F, FontStyle.Bold), Cursor = Cursors.Hand };
        copy.FlatAppearance.BorderColor = Color.FromArgb(29, 75, 58);
        copy.Click += CopyButton_Click;
        right.Controls.Add(LogList);
        right.Controls.Add(logSub);
        right.Controls.Add(logTitle);
        right.Controls.Add(copy);

        var footer = new Label { Text = "NEXUS CORE  •  DECIMAL ENGINE  •  KEYBOARD ENABLED     |     ENTER = EXECUTE   ESC = RESET", Dock = DockStyle.Bottom, Height = 28, TextAlign = ContentAlignment.MiddleCenter, Font = new Font("Consolas", 8F), ForeColor = Color.FromArgb(70, 111, 96), BackColor = Color.FromArgb(7, 12, 15) };
        Controls.Add(footer);
        footer.BringToFront();
    }

    private static bool IsOperator(string key) => key is "AC" or "⌫" or "%" or "÷" or "×" or "−" or "+" or "±" or "=";
}
